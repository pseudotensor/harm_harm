splint -line-len=150 +gnuextensions -weak -usedef -nestcomment -varuse -retvalother -fcnuse -fixedformalarray *.c &> splintwarnings.txt
