//GODMARK: don't know how to use FTYPE here -- FTYPE defined in global.h 
// need not static so other files can access settings
struct Ccoordparams coordparams;
