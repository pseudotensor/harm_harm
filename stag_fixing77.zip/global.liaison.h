
#define DOINGGRMHDTYPECODE 0 // always 0
#define DOINGGRRAYTYPECODE 0 // always 0
#define DOINGLIAISONTYPECODE 1 // always 1
#include "global.general.h"
