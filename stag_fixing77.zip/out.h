# 1 "defnprs.h"
# 1 "<built-in>"
# 1 "<command line>"
# 1 "defnprs.h"
